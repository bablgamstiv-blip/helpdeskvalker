package ru.helpdeskeddy.controller;

import jakarta.servlet.http.HttpSession;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import ru.helpdeskeddy.repository.KnowledgeArticleRepository;

import static org.hamcrest.Matchers.containsString;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class HelpDeskPagesTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private KnowledgeArticleRepository articleRepository;

    @Test
    void protectedPagesRedirectToLoginWhenSessionIsMissing() throws Exception {
        mockMvc.perform(get("/dashboard")).andExpect(redirectedUrl("/login"));
        mockMvc.perform(get("/tickets")).andExpect(redirectedUrl("/login"));
        mockMvc.perform(get("/tickets/1")).andExpect(redirectedUrl("/login"));
        mockMvc.perform(get("/knowledge")).andExpect(redirectedUrl("/login"));
        mockMvc.perform(get("/sla")).andExpect(redirectedUrl("/login"));
        mockMvc.perform(get("/automation")).andExpect(redirectedUrl("/login"));
        mockMvc.perform(get("/settings")).andExpect(redirectedUrl("/login"));
    }

    @Test
    void allApplicationSectionsRenderAndSupportSearch() throws Exception {
        MockHttpSession session = login();
        long articleId = articleRepository.findAll().getFirst().getId();

        mockMvc.perform(get("/dashboard").session(session))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Динамика обращений")))
                .andExpect(content().string(containsString("Каналы обращений")));
        mockMvc.perform(get("/tickets").session(session))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Все обращения")));
        mockMvc.perform(get("/tickets").param("channel", "Telegram").param("priority", "Срочный").session(session))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("channel-telegram")))
                .andExpect(content().string(containsString("priority-urgent")));
        mockMvc.perform(get("/tickets/1").session(session))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Переписка")));
        mockMvc.perform(get("/knowledge").session(session))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("База знаний")));
        mockMvc.perform(get("/knowledge").param("q", "пароль").session(session))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Безопасность аккаунта")));
        mockMvc.perform(get("/knowledge/" + articleId).session(session))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("article-content")));
        mockMvc.perform(get("/sla").session(session))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Соблюдение SLA")));
        mockMvc.perform(get("/automation").session(session))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Примеры правил")));
        mockMvc.perform(get("/settings").session(session))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Хранение данных")));
    }

    @Test
    void loginRejectsIncorrectCredentialsAndAcceptsDemoCredentials() throws Exception {
        mockMvc.perform(post("/login").param("username", "admin").param("password", "incorrect"))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Неверный логин или пароль")));

        MvcResult result = mockMvc.perform(post("/login").param("username", "admin").param("password", "admin"))
                .andExpect(redirectedUrl("/dashboard"))
                .andReturn();

        HttpSession session = result.getRequest().getSession(false);
        assertEquals(Boolean.TRUE, session.getAttribute("authenticated"));
    }

    @Test
    void conversationMessagesAndTicketPropertiesCanBeUpdated() throws Exception {
        MockHttpSession session = login();

        mockMvc.perform(post("/tickets/1/messages").session(session)
                        .param("body", "Тестовая внутренняя заметка").param("internal", "true"))
                .andExpect(redirectedUrl("/tickets/1"));
        mockMvc.perform(get("/tickets/1").session(session))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("Тестовая внутренняя заметка")))
                .andExpect(content().string(containsString("Внутренняя заметка добавлена")));

        mockMvc.perform(post("/tickets/1/details").session(session)
                        .param("status", "В работе").param("priority", "Высокий").param("assigneeId", "2"))
                .andExpect(redirectedUrl("/tickets/1"));
        mockMvc.perform(get("/tickets/1").session(session))
                .andExpect(status().isOk())
                .andExpect(content().string(containsString("status-progress")))
                .andExpect(content().string(containsString("Параметры обращения обновлены")));
    }

    private MockHttpSession login() throws Exception {
        MvcResult result = mockMvc.perform(post("/login")
                        .param("username", "admin")
                        .param("password", "admin"))
                .andExpect(redirectedUrl("/dashboard"))
                .andReturn();
        return (MockHttpSession) result.getRequest().getSession(false);
    }
}
