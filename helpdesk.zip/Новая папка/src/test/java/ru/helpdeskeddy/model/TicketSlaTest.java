package ru.helpdeskeddy.model;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

class TicketSlaTest {

    @Test
    void categorizesAndFormatsOverdueAndUpcomingSla() {
        assertSla(-65, "danger", "Просрочено на 1 ч 5 мин");
        assertSla(0, "warning", "Осталось 0 мин");
        assertSla(30, "warning", "Осталось 30 мин");
        assertSla(31, "safe", "Осталось 31 мин");
        assertSla(90, "safe", "Осталось 1 ч 30 мин");
    }

    private void assertSla(int minutes, String expectedClass, String expectedLabel) {
        Ticket ticket = new Ticket("Тема", "Новый", "Email", "Обычный", minutes,
                LocalDateTime.now(), new Customer("Анна Иванова", "anna@example.ru", "Компания"),
                new Agent("Елена Петрова", "elena@example.ru", "ЕП"));

        assertEquals(expectedClass, ticket.getSlaClass());
        assertEquals(expectedLabel, ticket.getSlaLabel());
    }
}
