const sidebar = document.querySelector('.sidebar');
const menuToggle = document.querySelector('.mobile-menu');

if (sidebar && menuToggle) {
    const backdrop = document.createElement('button');
    backdrop.className = 'mobile-menu-backdrop';
    backdrop.type = 'button';
    backdrop.setAttribute('aria-label', 'Закрыть меню');
    backdrop.hidden = true;
    document.body.append(backdrop);

    const setMenuOpen = (isOpen) => {
        sidebar.classList.toggle('sidebar-open', isOpen);
        backdrop.hidden = !isOpen;
        menuToggle.setAttribute('aria-expanded', String(isOpen));
    };

    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.addEventListener('click', () => setMenuOpen(!sidebar.classList.contains('sidebar-open')));
    sidebar.querySelector('[data-menu-close]').addEventListener('click', () => setMenuOpen(false));
    sidebar.querySelectorAll('.app-nav .nav-link').forEach((link) => {
        link.addEventListener('click', () => setMenuOpen(false));
    });
    backdrop.addEventListener('click', () => setMenuOpen(false));
    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            setMenuOpen(false);
        }
    });
}
