package ru.helpdeskeddy.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import ru.helpdeskeddy.model.Ticket;
import ru.helpdeskeddy.service.TicketService;

import java.util.List;

@Controller
public class WorkspaceController {

    private final TicketService ticketService;

    public WorkspaceController(TicketService ticketService) {
        this.ticketService = ticketService;
    }

    @GetMapping("/sla")
    public String sla(HttpSession session, Model model) {
        if (!authenticated(session)) {
            return "redirect:/login";
        }
        List<Ticket> tickets = ticketService.findTickets(null, null, null, null);
        model.addAttribute("tickets", tickets);
        model.addAttribute("overdueCount", tickets.stream().filter(ticket -> ticket.getSlaRemainingMinutes() < 0).count());
        model.addAttribute("warningCount", tickets.stream().filter(ticket ->
                ticket.getSlaRemainingMinutes() >= 0 && ticket.getSlaRemainingMinutes() <= 30).count());
        model.addAttribute("safeCount", tickets.stream().filter(ticket -> ticket.getSlaRemainingMinutes() > 30).count());
        addHeaderModel(session, model, "sla");
        return "sla";
    }

    @GetMapping("/automation")
    public String automation(HttpSession session, Model model) {
        if (!authenticated(session)) {
            return "redirect:/login";
        }
        addHeaderModel(session, model, "automation");
        return "automation";
    }

    @GetMapping("/settings")
    public String settings(HttpSession session, Model model) {
        if (!authenticated(session)) {
            return "redirect:/login";
        }
        addHeaderModel(session, model, "settings");
        return "settings";
    }

    private void addHeaderModel(HttpSession session, Model model, String activePage) {
        model.addAttribute("userName", session.getAttribute("userName"));
        model.addAttribute("activePage", activePage);
    }

    private boolean authenticated(HttpSession session) {
        return Boolean.TRUE.equals(session.getAttribute("authenticated"));
    }
}
