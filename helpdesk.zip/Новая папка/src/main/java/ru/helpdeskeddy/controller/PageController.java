package ru.helpdeskeddy.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import ru.helpdeskeddy.service.TicketService;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Controller
public class PageController {

    private final TicketService ticketService;

    public PageController(TicketService ticketService) {
        this.ticketService = ticketService;
    }

    @GetMapping("/")
    public String home(HttpSession session) {
        return Boolean.TRUE.equals(session.getAttribute("authenticated"))
                ? "redirect:/dashboard"
                : "redirect:/login";
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        if (!Boolean.TRUE.equals(session.getAttribute("authenticated"))) {
            return "redirect:/login";
        }
        Map<String, Long> statusCounts = ticketService.countByStatus();
        List<String> chartLabels = java.util.stream.IntStream.rangeClosed(0, 6)
                .mapToObj(offset -> LocalDate.now().minusDays(6L - offset)
                        .format(DateTimeFormatter.ofPattern("dd.MM", Locale.forLanguageTag("ru"))))
                .toList();
        model.addAttribute("newCount", statusCounts.getOrDefault("Новый", 0L));
        model.addAttribute("inProgressCount", statusCounts.getOrDefault("В работе", 0L));
        model.addAttribute("resolvedCount", statusCounts.getOrDefault("Решён", 0L));
        model.addAttribute("overdueCount", ticketService.countOverdue());
        model.addAttribute("chartLabels", chartLabels);
        model.addAttribute("dailyCounts", ticketService.dailyCounts());
        model.addAttribute("channelLabels", TicketService.CHANNELS);
        model.addAttribute("channelCounts", ticketService.channelCounts());
        model.addAttribute("recentTickets", ticketService.findTickets(null, null, null, null).stream().limit(5).toList());
        model.addAttribute("today", LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM", Locale.forLanguageTag("ru"))));
        model.addAttribute("userName", session.getAttribute("userName"));
        model.addAttribute("activePage", "dashboard");
        return "dashboard";
    }
}
