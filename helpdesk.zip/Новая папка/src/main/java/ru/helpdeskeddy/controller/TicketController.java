package ru.helpdeskeddy.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import ru.helpdeskeddy.model.Agent;
import ru.helpdeskeddy.model.Ticket;
import ru.helpdeskeddy.repository.AgentRepository;
import ru.helpdeskeddy.service.TicketService;

@Controller
public class TicketController {

    private final TicketService ticketService;
    private final AgentRepository agentRepository;

    public TicketController(TicketService ticketService, AgentRepository agentRepository) {
        this.ticketService = ticketService;
        this.agentRepository = agentRepository;
    }

    @GetMapping("/tickets")
    public String tickets(@RequestParam(required = false) String status,
                          @RequestParam(required = false) String channel,
                          @RequestParam(required = false) String priority,
                          @RequestParam(required = false) String q,
                          HttpSession session, Model model) {
        if (!authenticated(session)) {
            return "redirect:/login";
        }
        model.addAttribute("tickets", ticketService.findTickets(status, channel, priority, q));
        model.addAttribute("statuses", TicketService.STATUSES);
        model.addAttribute("channels", TicketService.CHANNELS);
        model.addAttribute("priorities", TicketService.PRIORITIES);
        model.addAttribute("selectedStatus", status == null ? "" : status);
        model.addAttribute("selectedChannel", channel == null ? "" : channel);
        model.addAttribute("selectedPriority", priority == null ? "" : priority);
        model.addAttribute("query", q == null ? "" : q);
        model.addAttribute("userName", session.getAttribute("userName"));
        model.addAttribute("activePage", "tickets");
        return "tickets";
    }

    @GetMapping("/tickets/{id}")
    public String ticket(@PathVariable Long id, HttpSession session, Model model) {
        if (!authenticated(session)) {
            return "redirect:/login";
        }
        Ticket ticket = ticketService.findTicket(id);
        var messages = ticketService.findMessages(id);
        model.addAttribute("ticket", ticket);
        model.addAttribute("messages", messages);
        model.addAttribute("messageCountLabel", messageCountLabel(messages.size()));
        model.addAttribute("agents", agentRepository.findAll());
        model.addAttribute("statuses", TicketService.STATUSES);
        model.addAttribute("priorities", TicketService.PRIORITIES);
        model.addAttribute("userName", session.getAttribute("userName"));
        model.addAttribute("activePage", "tickets");
        return "ticket-detail";
    }

    @PostMapping("/tickets/{id}/messages")
    public String addMessage(@PathVariable Long id, @RequestParam String body,
                             @RequestParam(defaultValue = "false") boolean internal,
                             HttpSession session, RedirectAttributes redirectAttributes) {
        if (!authenticated(session)) {
            return "redirect:/login";
        }
        ticketService.addMessage(id, body, internal);
        redirectAttributes.addFlashAttribute("success", internal ? "Внутренняя заметка добавлена" : "Ответ отправлен");
        return "redirect:/tickets/" + id;
    }

    @PostMapping("/tickets/{id}/details")
    public String updateDetails(@PathVariable Long id, @RequestParam String status,
                                @RequestParam String priority, @RequestParam Long assigneeId,
                                HttpSession session, RedirectAttributes redirectAttributes) {
        if (!authenticated(session)) {
            return "redirect:/login";
        }
        ticketService.updateTicket(id, status, priority, assigneeId);
        redirectAttributes.addFlashAttribute("success", "Параметры обращения обновлены");
        return "redirect:/tickets/" + id;
    }

    private boolean authenticated(HttpSession session) {
        return Boolean.TRUE.equals(session.getAttribute("authenticated"));
    }

    private String messageCountLabel(int count) {
        int lastTwoDigits = count % 100;
        if (lastTwoDigits >= 11 && lastTwoDigits <= 14) {
            return count + " сообщений";
        }
        return switch (count % 10) {
            case 1 -> count + " сообщение";
            case 2, 3, 4 -> count + " сообщения";
            default -> count + " сообщений";
        };
    }
}
