package ru.helpdeskeddy.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import ru.helpdeskeddy.service.KnowledgeService;

@Controller
public class KnowledgeController {

    private final KnowledgeService knowledgeService;

    public KnowledgeController(KnowledgeService knowledgeService) {
        this.knowledgeService = knowledgeService;
    }

    @GetMapping("/knowledge")
    public String knowledge(@RequestParam(required = false) String category,
                            @RequestParam(required = false) String q,
                            HttpSession session, Model model) {
        if (!authenticated(session)) {
            return "redirect:/login";
        }
        model.addAttribute("articles", knowledgeService.findArticles(category, q));
        model.addAttribute("articleCount", knowledgeService.findArticles(null, null).size());
        model.addAttribute("categories", knowledgeService.findCategories());
        model.addAttribute("selectedCategory", category == null ? "" : category);
        model.addAttribute("query", q == null ? "" : q);
        model.addAttribute("userName", session.getAttribute("userName"));
        model.addAttribute("activePage", "knowledge");
        return "knowledge";
    }

    @GetMapping("/knowledge/{id}")
    public String article(@PathVariable Long id, HttpSession session, Model model) {
        if (!authenticated(session)) {
            return "redirect:/login";
        }
        model.addAttribute("article", knowledgeService.findArticle(id));
        model.addAttribute("userName", session.getAttribute("userName"));
        model.addAttribute("activePage", "knowledge");
        return "knowledge-article";
    }

    private boolean authenticated(HttpSession session) {
        return Boolean.TRUE.equals(session.getAttribute("authenticated"));
    }
}
