package ru.helpdeskeddy.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {

    @GetMapping("/login")
    public String login(HttpSession session) {
        if (Boolean.TRUE.equals(session.getAttribute("authenticated"))) {
            return "redirect:/dashboard";
        }
        return "login";
    }

    @PostMapping("/login")
    public String authenticate(@RequestParam String username, @RequestParam String password,
                               HttpSession session, Model model) {
        if ("admin".equals(username) && "admin".equals(password)) {
            session.setAttribute("authenticated", true);
            session.setAttribute("userName", "Администратор");
            return "redirect:/dashboard";
        }
        model.addAttribute("error", "Неверный логин или пароль");
        return "login";
    }

    @PostMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}
