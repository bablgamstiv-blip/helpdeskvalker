package ru.helpdeskeddy.model;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

@Entity
@Table(name = "ticket_messages")
public class TicketMessage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne(fetch = FetchType.EAGER)
    private Ticket ticket;
    private String authorName;
    private String authorInitials;
    private String body;
    private boolean internal;
    private LocalDateTime createdAt;

    protected TicketMessage() {
    }

    public TicketMessage(Ticket ticket, String authorName, String authorInitials, String body,
                         boolean internal, LocalDateTime createdAt) {
        this.ticket = ticket;
        this.authorName = authorName;
        this.authorInitials = authorInitials;
        this.body = body;
        this.internal = internal;
        this.createdAt = createdAt;
    }

    public Long getId() {
        return id;
    }

    public Ticket getTicket() {
        return ticket;
    }

    public String getAuthorName() {
        return authorName;
    }

    public String getAuthorInitials() {
        return authorInitials;
    }

    public String getBody() {
        return body;
    }

    public boolean isInternal() {
        return internal;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
}
