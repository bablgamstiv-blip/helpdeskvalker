package ru.helpdeskeddy.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private String company;

    protected Customer() {
    }

    public Customer(String name, String email, String company) {
        this.name = name;
        this.email = email;
        this.company = company;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getCompany() {
        return company;
    }

    public String getInitials() {
        String[] nameParts = name.split(" ");
        return nameParts[0].substring(0, 1) + nameParts[nameParts.length - 1].substring(0, 1);
    }
}
