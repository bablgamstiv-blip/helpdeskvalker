package ru.helpdeskeddy.model;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

@Entity
@Table(name = "tickets")
public class Ticket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String subject;
    private String status;
    private String channel;
    private String priority;
    private int slaRemainingMinutes;
    private LocalDateTime createdAt;

    @ManyToOne(fetch = FetchType.EAGER)
    private Customer customer;

    @ManyToOne(fetch = FetchType.EAGER)
    private Agent assignee;

    protected Ticket() {
    }

    public Ticket(String subject, String status, String channel, String priority,
                  int slaRemainingMinutes, LocalDateTime createdAt, Customer customer, Agent assignee) {
        this.subject = subject;
        this.status = status;
        this.channel = channel;
        this.priority = priority;
        this.slaRemainingMinutes = slaRemainingMinutes;
        this.createdAt = createdAt;
        this.customer = customer;
        this.assignee = assignee;
    }

    public Long getId() {
        return id;
    }

    public String getSubject() {
        return subject;
    }

    public String getStatus() {
        return status;
    }

    public String getChannel() {
        return channel;
    }

    public String getPriority() {
        return priority;
    }

    public int getSlaRemainingMinutes() {
        return slaRemainingMinutes;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public Customer getCustomer() {
        return customer;
    }

    public Agent getAssignee() {
        return assignee;
    }

    public void updateDetails(String status, String priority, Agent assignee) {
        this.status = status;
        this.priority = priority;
        this.assignee = assignee;
    }

    public String getChannelIcon() {
        return switch (channel) {
            case "Email" -> "bi-envelope";
            case "Telegram" -> "bi-telegram";
            case "WhatsApp" -> "bi-whatsapp";
            case "Чат" -> "bi-chat-dots";
            case "Телефон" -> "bi-telephone";
            case "VK" -> "bi-chat-left-dots";
            default -> "bi-question-circle";
        };
    }

    public String getChannelClass() {
        return switch (channel) {
            case "Email" -> "email";
            case "Telegram" -> "telegram";
            case "WhatsApp" -> "whatsapp";
            case "Чат" -> "chat";
            case "Телефон" -> "phone";
            case "VK" -> "vk";
            default -> "other";
        };
    }

    public String getStatusClass() {
        return switch (status) {
            case "Новый" -> "new";
            case "В работе" -> "progress";
            case "Ожидает ответа" -> "waiting";
            case "Решён" -> "resolved";
            default -> "other";
        };
    }

    public String getPriorityClass() {
        return switch (priority) {
            case "Срочный" -> "urgent";
            case "Высокий" -> "high";
            case "Обычный" -> "normal";
            case "Низкий" -> "low";
            default -> "other";
        };
    }

    public String getSlaClass() {
        if (slaRemainingMinutes < 0) {
            return "danger";
        }
        return slaRemainingMinutes <= 30 ? "warning" : "safe";
    }

    public String getSlaLabel() {
        if (slaRemainingMinutes < 0) {
            return "Просрочено на " + formatDuration(-slaRemainingMinutes);
        }
        return "Осталось " + formatDuration(slaRemainingMinutes);
    }

    private String formatDuration(int minutes) {
        if (minutes >= 60) {
            return minutes / 60 + " ч " + minutes % 60 + " мин";
        }
        return minutes + " мин";
    }
}
