package ru.helpdeskeddy.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class KnowledgeArticle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String title;
    private String category;
    private String summary;
    @jakarta.persistence.Column(length = 4000)
    private String content;

    protected KnowledgeArticle() {
    }

    public KnowledgeArticle(String title, String category, String summary, String content) {
        this.title = title;
        this.category = category;
        this.summary = summary;
        this.content = content;
    }

    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getCategory() {
        return category;
    }

    public String getSummary() {
        return summary;
    }

    public String getContent() {
        return content;
    }
}
