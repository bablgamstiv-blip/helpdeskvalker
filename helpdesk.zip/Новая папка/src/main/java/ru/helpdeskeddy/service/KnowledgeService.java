package ru.helpdeskeddy.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.helpdeskeddy.model.KnowledgeArticle;
import ru.helpdeskeddy.repository.KnowledgeArticleRepository;

import java.util.Comparator;
import java.util.List;

@Service
public class KnowledgeService {

    private final KnowledgeArticleRepository articleRepository;

    public KnowledgeService(KnowledgeArticleRepository articleRepository) {
        this.articleRepository = articleRepository;
    }

    @Transactional(readOnly = true)
    public List<KnowledgeArticle> findArticles(String category, String query) {
        String search = query == null ? "" : query.trim().toLowerCase(java.util.Locale.ROOT);
        return articleRepository.findAll().stream()
                .filter(article -> category == null || category.isBlank() || category.equals(article.getCategory()))
                .filter(article -> search.isBlank()
                        || article.getTitle().toLowerCase(java.util.Locale.ROOT).contains(search)
                        || article.getSummary().toLowerCase(java.util.Locale.ROOT).contains(search)
                        || article.getContent().toLowerCase(java.util.Locale.ROOT).contains(search)
                        || article.getCategory().toLowerCase(java.util.Locale.ROOT).contains(search))
                .sorted(Comparator.comparing(KnowledgeArticle::getCategory).thenComparing(KnowledgeArticle::getTitle))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<String> findCategories() {
        return articleRepository.findAll().stream()
                .map(KnowledgeArticle::getCategory)
                .distinct()
                .sorted()
                .toList();
    }

    @Transactional(readOnly = true)
    public KnowledgeArticle findArticle(Long id) {
        return articleRepository.findById(id).orElseThrow(
                () -> new IllegalArgumentException("Статья с номером " + id + " не найдена"));
    }
}
