package ru.helpdeskeddy.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.helpdeskeddy.model.Agent;
import ru.helpdeskeddy.model.Ticket;
import ru.helpdeskeddy.model.TicketMessage;
import ru.helpdeskeddy.repository.AgentRepository;
import ru.helpdeskeddy.repository.TicketMessageRepository;
import ru.helpdeskeddy.repository.TicketRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
public class TicketService {

    public static final List<String> STATUSES = List.of("Новый", "В работе", "Ожидает ответа", "Решён");
    public static final List<String> CHANNELS = List.of("Email", "Telegram", "WhatsApp", "Чат", "Телефон", "VK");
    public static final List<String> PRIORITIES = List.of("Низкий", "Обычный", "Высокий", "Срочный");

    private final TicketRepository ticketRepository;
    private final TicketMessageRepository messageRepository;
    private final AgentRepository agentRepository;

    public TicketService(TicketRepository ticketRepository, TicketMessageRepository messageRepository,
                         AgentRepository agentRepository) {
        this.ticketRepository = ticketRepository;
        this.messageRepository = messageRepository;
        this.agentRepository = agentRepository;
    }

    @Transactional(readOnly = true)
    public List<Ticket> findTickets(String status, String channel, String priority, String query) {
        String normalizedQuery = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        return ticketRepository.findAll().stream()
                .filter(ticket -> status == null || status.isBlank() || status.equals(ticket.getStatus()))
                .filter(ticket -> channel == null || channel.isBlank() || channel.equals(ticket.getChannel()))
                .filter(ticket -> priority == null || priority.isBlank() || priority.equals(ticket.getPriority()))
                .filter(ticket -> normalizedQuery.isBlank()
                        || ticket.getSubject().toLowerCase(Locale.ROOT).contains(normalizedQuery)
                        || ticket.getCustomer().getName().toLowerCase(Locale.ROOT).contains(normalizedQuery)
                        || String.valueOf(ticket.getId()).equals(normalizedQuery))
                .sorted(Comparator.comparing(Ticket::getCreatedAt).reversed())
                .toList();
    }

    @Transactional(readOnly = true)
    public Ticket findTicket(Long id) {
        return ticketRepository.findById(id).orElseThrow(
                () -> new IllegalArgumentException("Обращение с номером " + id + " не найдено"));
    }

    @Transactional(readOnly = true)
    public List<TicketMessage> findMessages(Long ticketId) {
        findTicket(ticketId);
        return messageRepository.findByTicketIdOrderByCreatedAtAsc(ticketId);
    }

    @Transactional(readOnly = true)
    public Map<String, Long> countByStatus() {
        List<Ticket> tickets = ticketRepository.findAll();
        return STATUSES.stream().collect(Collectors.toMap(
                Function.identity(),
                status -> tickets.stream().filter(ticket -> status.equals(ticket.getStatus())).count()
        ));
    }

    @Transactional(readOnly = true)
    public long countOverdue() {
        return ticketRepository.findAll().stream().filter(ticket -> ticket.getSlaRemainingMinutes() < 0).count();
    }

    @Transactional(readOnly = true)
    public List<Integer> dailyCounts() {
        LocalDate today = LocalDate.now();
        Map<LocalDate, Integer> counts = ticketRepository.findAll().stream()
                .collect(Collectors.groupingBy(ticket -> ticket.getCreatedAt().toLocalDate(),
                        Collectors.summingInt(ticket -> 1)));
        return IntStream.rangeClosed(0, 6)
                .mapToObj(offset -> counts.getOrDefault(today.minusDays(6L - offset), 0))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<Long> channelCounts() {
        Map<String, Long> counts = ticketRepository.findAll().stream()
                .collect(Collectors.groupingBy(Ticket::getChannel, Collectors.counting()));
        return CHANNELS.stream().map(channel -> counts.getOrDefault(channel, 0L)).toList();
    }

    @Transactional
    public void addMessage(Long ticketId, String body, boolean internal) {
        String messageBody = body == null ? "" : body.trim();
        if (messageBody.isBlank()) {
            throw new IllegalArgumentException("Введите текст сообщения");
        }
        Ticket ticket = findTicket(ticketId);
        messageRepository.save(new TicketMessage(ticket, "Администратор", "АД", messageBody, internal, LocalDateTime.now()));
    }

    @Transactional
    public void updateTicket(Long ticketId, String status, String priority, Long assigneeId) {
        if (!STATUSES.contains(status) || !PRIORITIES.contains(priority)) {
            throw new IllegalArgumentException("Выбран недопустимый статус или приоритет");
        }
        Ticket ticket = findTicket(ticketId);
        Agent assignee = agentRepository.findById(assigneeId).orElseThrow(
                () -> new IllegalArgumentException("Выбранный исполнитель не найден"));
        ticket.updateDetails(status, priority, assignee);
        ticketRepository.save(ticket);
    }
}
