package ru.helpdeskeddy.service;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.helpdeskeddy.model.Agent;
import ru.helpdeskeddy.model.Customer;
import ru.helpdeskeddy.model.KnowledgeArticle;
import ru.helpdeskeddy.model.Ticket;
import ru.helpdeskeddy.model.TicketMessage;
import ru.helpdeskeddy.repository.AgentRepository;
import ru.helpdeskeddy.repository.CustomerRepository;
import ru.helpdeskeddy.repository.KnowledgeArticleRepository;
import ru.helpdeskeddy.repository.TicketMessageRepository;
import ru.helpdeskeddy.repository.TicketRepository;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class DemoDataService implements CommandLineRunner {

    private final AgentRepository agentRepository;
    private final CustomerRepository customerRepository;
    private final TicketRepository ticketRepository;
    private final KnowledgeArticleRepository articleRepository;
    private final TicketMessageRepository messageRepository;

    public DemoDataService(AgentRepository agentRepository, CustomerRepository customerRepository,
                          TicketRepository ticketRepository, KnowledgeArticleRepository articleRepository,
                          TicketMessageRepository messageRepository) {
        this.agentRepository = agentRepository;
        this.customerRepository = customerRepository;
        this.ticketRepository = ticketRepository;
        this.articleRepository = articleRepository;
        this.messageRepository = messageRepository;
    }

    @Override
    @Transactional
    public void run(String... args) {
        if (ticketRepository.count() > 0) {
            return;
        }

        List<Agent> agents = agentRepository.saveAll(List.of(
                new Agent("Анна Петрова", "anna@helpdeskeddy.ru", "АП"),
                new Agent("Михаил Смирнов", "mikhail@helpdeskeddy.ru", "МС"),
                new Agent("Елена Иванова", "elena@helpdeskeddy.ru", "ЕИ"),
                new Agent("Дмитрий Козлов", "dmitry@helpdeskeddy.ru", "ДК"),
                new Agent("Ольга Соколова", "olga@helpdeskeddy.ru", "ОС")
        ));

        List<Customer> customers = customerRepository.saveAll(List.of(
                new Customer("Александр Волков", "a.volkov@example.ru", "Вектор"),
                new Customer("Мария Соколова", "m.sokolova@example.ru", "ЛайтСофт"),
                new Customer("Иван Морозов", "i.morozov@example.ru", "Маяк"),
                new Customer("Екатерина Лебедева", "e.lebedeva@example.ru", "Старт"),
                new Customer("Сергей Новиков", "s.novikov@example.ru", "Призма"),
                new Customer("Наталья Фёдорова", "n.fedorova@example.ru", "Клевер"),
                new Customer("Павел Орлов", "p.orlov@example.ru", "Атлас"),
                new Customer("Татьяна Белова", "t.belova@example.ru", "Фокус"),
                new Customer("Артём Егоров", "a.egorov@example.ru", "Орбита"),
                new Customer("Юлия Павлова", "y.pavlova@example.ru", "Комета")
        ));

        List<String> subjects = List.of(
                "Не получается войти в личный кабинет", "Вопрос по оплате тарифа", "Не пришло письмо подтверждения",
                "Как изменить данные компании?", "Ошибка при загрузке документа", "Нужна копия закрывающих документов",
                "Не отображается история заказов", "Помогите настроить уведомления", "Сбой при оформлении заказа",
                "Запрос на возврат средств", "Не работает интеграция каталога", "Можно сменить тариф?",
                "Проблема с двухфакторной авторизацией", "Уточнение по срокам доставки", "Не открывается приложение",
                "Добавьте нового сотрудника", "Не удаётся скачать отчёт", "Вопрос по настройке профиля",
                "Дублируются уведомления", "Изменился контактный телефон", "Ошибка в счёте за месяц",
                "Нужна помощь с настройкой", "Заказ отмечен как отменённый", "Вопрос по API-доступу",
                "Как связаться с менеджером?"
        );
        List<String> statuses = List.of("Новый", "В работе", "Ожидает ответа", "Решён");
        List<String> channels = List.of("Email", "Telegram", "WhatsApp", "Чат", "Телефон", "VK");
        List<String> priorities = List.of("Низкий", "Обычный", "Высокий", "Срочный");
        LocalDateTime now = LocalDateTime.now();

        for (int i = 0; i < subjects.size(); i++) {
            LocalDateTime createdAt = now.minusHours(i * 3L + 1);
            Ticket ticket = ticketRepository.save(new Ticket(
                    subjects.get(i),
                    statuses.get(i % statuses.size()),
                    channels.get(i % channels.size()),
                    priorities.get(i % priorities.size()),
                    new int[]{210, 95, 32, -18, 360, 14, 125, -45, 52, 280, 75, 18, 190, -5, 44,
                            320, 67, 8, 145, 28, 420, 12, 88, -62, 55}[i],
                    createdAt,
                    customers.get(i % customers.size()),
                    agents.get(i % agents.size())
            ));
            messageRepository.save(new TicketMessage(ticket, ticket.getCustomer().getName(), ticket.getCustomer().getInitials(),
                    "Здравствуйте! Пишу по поводу обращения: «" + ticket.getSubject() + "». Подскажите, пожалуйста, как можно решить этот вопрос?",
                    false, createdAt.plusMinutes(5)));
            messageRepository.save(new TicketMessage(ticket, agents.get(i % agents.size()).getName(),
                    agents.get(i % agents.size()).getInitials(),
                    "Здравствуйте! Спасибо, что написали. Мы уже разбираемся в ситуации и скоро вернёмся к вам с ответом.",
                    false, createdAt.plusMinutes(20)));
            if (i % 5 == 0) {
                messageRepository.save(new TicketMessage(ticket, "Анна Петрова", "АП",
                        "Проверить детали запроса и сообщить клиенту о следующих шагах.",
                        true, createdAt.plusMinutes(25)));
            }
        }

        articleRepository.saveAll(List.of(
                new KnowledgeArticle("Восстановление доступа к аккаунту", "Аккаунт",
                        "Что делать, если вы забыли пароль или не можете войти.",
                        "1. Откройте страницу входа и выберите «Забыли пароль?».\n2. Укажите адрес электронной почты, связанный с аккаунтом.\n3. Откройте письмо для сброса пароля и перейдите по ссылке. Если письма нет, проверьте папку «Спам».\n4. Придумайте новый уникальный пароль и войдите с ним.\n\nСсылка для сброса пароля ограничена по времени. Если доступ к почте потерян, обратитесь в службу поддержки с названием вашей компании."),
                new KnowledgeArticle("Как изменить тарифный план", "Оплата и тарифы",
                        "Где посмотреть доступные тарифы и выбрать подходящий.",
                        "Откройте настройки организации и перейдите в раздел «Оплата и тарифы». Здесь можно сравнить текущий и доступные планы, условия оплаты и список функций.\n\nЧтобы изменить тариф, выберите нужный план и подтвердите изменение. Информация о дате перехода и перерасчёте отобразится перед подтверждением. Изменение тарифного плана доступно администраторам организации.\n\nЕсли нужного плана нет в списке, напишите в поддержку и укажите название организации."),
                new KnowledgeArticle("Настройка уведомлений", "Настройки",
                        "Управление каналами и частотой уведомлений.",
                        "Откройте профиль и выберите «Уведомления». В настройках можно указать, для каких событий получать уведомления и куда их доставлять.\n\nСохраните изменения кнопкой внизу страницы. Если уведомление не пришло, проверьте правильность контактных данных и папку «Спам». В демонстрационной версии HelpDeskEddy внешняя доставка уведомлений отключена."),
                new KnowledgeArticle("Добавление сотрудника в команду", "Аккаунт",
                        "Приглашение коллег и настройка их ролей.",
                        "Администратор организации может приглашать сотрудников из раздела команды.\n1. Нажмите «Добавить сотрудника».\n2. Укажите имя и рабочий адрес электронной почты.\n3. Выберите роль: права доступа зависят от обязанностей сотрудника.\n4. Подтвердите приглашение.\n\nПосле принятия приглашения сотрудник появится в списке команды. Не передавайте пароль от своей учётной записи коллегам."),
                new KnowledgeArticle("Скачивание закрывающих документов", "Оплата и тарифы",
                        "Как найти и скачать счета и акты в личном кабинете.",
                        "Откройте настройки организации и перейдите в раздел «Оплата и тарифы». В истории оплат выберите нужный период.\n\nДоступные счета и закрывающие документы можно открыть или скачать из карточки платежа. Проверьте юридические реквизиты организации. Если документа за нужный период нет, укажите номер счёта и дату платежа в обращении в поддержку."),
                new KnowledgeArticle("Загрузка документов", "Работа с сервисом",
                        "Требования к формату и размеру загружаемых файлов.",
                        "Чтобы приложить документ, нажмите кнопку загрузки файла в соответствующем разделе и выберите файл на устройстве. Дождитесь окончания загрузки, прежде чем закрыть страницу.\n\nЕсли загрузка не работает, проверьте соединение, формат и размер файла, указанный в подсказке сервиса. Попробуйте повторить загрузку в актуальной версии браузера. Не прикладывайте пароли и конфиденциальные данные в открытом виде."),
                new KnowledgeArticle("Частые вопросы по доставке", "Заказы",
                        "Статусы заказа, сроки обработки и способы доставки.",
                        "Статус заказа и его текущие детали можно посмотреть в истории заказов в личном кабинете. Срок доставки зависит от выбранного способа и региона и отображается в карточке заказа.\n\nЕсли статус долго не меняется, проверьте дату последнего обновления и номер заказа. При обращении в поддержку укажите номер заказа и контакт для ответа. Не создавайте повторный заказ, пока не проверите состояние текущего."),
                new KnowledgeArticle("Безопасность аккаунта", "Безопасность",
                        "Советы по защите учётной записи и двухфакторному входу.",
                        "Используйте уникальный пароль, который вы не применяете на других сайтах. Не отправляйте пароль и коды подтверждения сотрудникам поддержки.\n\nЕсли доступна двухфакторная авторизация, включите её в настройках профиля и сохраните резервные коды в безопасном месте. Завершайте работу на общих устройствах выходом из аккаунта. При подозрении на посторонний доступ сразу смените пароль и обратитесь в поддержку.")
        ));
    }
}
