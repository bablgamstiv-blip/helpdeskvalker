package ru.helpdeskeddy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.helpdeskeddy.model.TicketMessage;

import java.util.List;

public interface TicketMessageRepository extends JpaRepository<TicketMessage, Long> {
    List<TicketMessage> findByTicketIdOrderByCreatedAtAsc(Long ticketId);
}
