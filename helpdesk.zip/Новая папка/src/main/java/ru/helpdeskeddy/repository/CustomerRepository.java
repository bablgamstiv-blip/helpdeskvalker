package ru.helpdeskeddy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.helpdeskeddy.model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
}
