package ru.helpdeskeddy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.helpdeskeddy.model.KnowledgeArticle;

public interface KnowledgeArticleRepository extends JpaRepository<KnowledgeArticle, Long> {
}
