package ru.helpdeskeddy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.helpdeskeddy.model.Ticket;

public interface TicketRepository extends JpaRepository<Ticket, Long> {
}
