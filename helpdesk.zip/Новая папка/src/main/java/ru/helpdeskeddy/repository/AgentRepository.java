package ru.helpdeskeddy.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ru.helpdeskeddy.model.Agent;

public interface AgentRepository extends JpaRepository<Agent, Long> {
}
